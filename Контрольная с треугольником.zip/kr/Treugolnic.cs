﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kr
{
    class Treugolnic
    {
        Point one;
        Point two;
        Point free;
        public Treugolnic(Point one1, Point two1, Point free1)
        {
            one = one1;
            two = two1;
            free = free1;
        
        }
        public double perimetr()
        {
            Point  pr= new Point();
            pr.X = two.X - one.X;
            pr.Y = two.Y - one.Y;
            Point pr1 = new Point();
            pr1.X = free.X - two.X;
            pr1.Y = free.Y - two.Y;
            Point pr2 = new Point();
            pr2.X = one.X - free.X;
            pr2.Y = one.Y - free.Y;

            double d1 = Math.Sqrt(pr.X * pr.X + pr.Y * pr.Y);
            double d2 = Math.Sqrt(pr1.X * pr1.X + pr1.Y * pr1.Y);
            double d3 = Math.Sqrt(pr2.X * pr2.X + pr2.Y * pr2.Y);
            double perm;
            if (d1 + d2 <= d3 || d1 + d3 <= d2 || d2 + d3 <= d1)
            {
                perm = -1;
                return perm;
            }
             perm = d1 + d2 + d3;
            return perm;

        }
    }
}
