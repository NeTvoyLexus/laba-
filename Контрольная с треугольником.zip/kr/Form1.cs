﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kr
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Point one = new Point();
            one.X = int.Parse(textBox1.Text);
            one.Y = int.Parse(textBox4.Text);
            Point two = new Point();
            two.X = int.Parse(textBox2.Text);
            two.Y = int.Parse(textBox5.Text);
            Point free = new Point();
            free.X = int.Parse(textBox3.Text);
            free.Y = int.Parse(textBox6.Text);
            Treugolnic treug = new Treugolnic(one, two, free);
            double perimetr = treug.perimetr();
            if ( perimetr == -1)
            {
                MessageBox.Show(" Не выполняется неравенство треугольника");
            }
            textBox7.Text = perimetr.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ColorDialog col = new ColorDialog();
            col.ShowDialog();
            BackColor = col.Color;
        }
    }
}
